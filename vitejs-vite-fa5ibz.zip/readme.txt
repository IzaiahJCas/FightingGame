Hello welcome to my game, to play the game the controls are as follows:
player 1:
w - jump
a - left
d - right
e - attack

player 2:
i - jump 
j - left
l - right
u - attack

Reload page to play again.

Please play with a friend and enjoy!
